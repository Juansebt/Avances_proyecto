from django.apps import AppConfig


class AppDalbasConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "app_DAlbas"
